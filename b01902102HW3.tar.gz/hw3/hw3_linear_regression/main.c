#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int getSign(double x1, double x2);

void main() {
	double data[1000][3];
	int t, i;
	for (t = 0; t < 1000;t++) {
		//generate data
		for (i = 0; i < 1000; i++) {
			srand((unsigned)time(NULL));
			int sign = rand % 2; //x1
			if (sign == 0)
				data[i][0] = ((double)rand()/(double)RAND_MAX);
			else 
				data[i][0] = ((double)rand()/(double)RAND_MAX) * (-1);

			sign = rand % 2; //x2
			if (sign == 0)
				data[i][1] = ((double)rand()/(double)RAND_MAX);
			else 
				data[i][1] = ((double)rand()/(double)RAND_MAX) * (-1);

			data[i][2] = getSign(double x1, double x2); //y 

			if(i % 10 == 0) //flip y
				data[i][2] *= (-1);
		}

		//matrix x
		
	}
}

int getSign(double x1, double x2) {
	double sum = x1*x1 + x2*x2 - 0.6;
	if (sum > 0)
		return 1;
	else
		return -1;
}